<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\CategoryModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use DB;

class Category extends Component
{
	protected $listeners = ['get_cate' => 'get_data'];
	public $name, $parent_id, $category_id;
	public function get_data(){
		return CategoryModel::where(['parent_id' => 0])->orderBy('sort_order', 'ASC')->get();
	}
    public function render()
    {
    	$this->emit('get_cate');
    	 $info = [
            'categories' => $this->get_data(),
        ];
        
        return view('livewire.category', $info);
    }
    public function create()
    {
    	 $info = [
            'categories' => CategoryModel::orderBy('name', 'ASC')->get(),
        ];

        return view('livewire.create', $info);
    }
     public function store(Request $request){
     	$rules=[
            'name' => 'required',
            'parent_id' => 'nullable',
        ];

        $messages = [
            "name.required" => "Category name is required.",
        ];

        $validator = Validator::make($request->all(), $rules, $messages);
        
        if( $validator->fails() ){
            return back()->withErrors($validator)->withInput();
        } else {
            DB::beginTransaction();
            try {
                $info = [
                    "success" => FALSE,
                ];
                $query = [
                    'name' => $request->name,
                    'parent_id' => (!empty($request->parent_id))? $request->parent_id : 0,
                ];
    
                $category = CategoryModel::updateOrCreate(['category_id' => $request->category_id], $query);

                DB::commit();
                $info['success'] = TRUE;
            } catch (\Exception $e) {
                DB::rollback();
                $info['success'] = FALSE;
            }

            if(!$info['success']){
                return redirect(route('create'))->with('error', "Failed to save.");
            }
            $this->emit('get_cate');

            // return redirect(route('category-subcategory.edit', ['category_id' => $category->category_id]))->with('success', "Successfully saved.");

            // return $this->render();
        }

     }


}

@extends('layouts.app')

@section('content')
        
        <div class="container">
            <h2 class="text-center p-4 font-semibold">Laravel Drag, Drop and Sort Categories SubCategories using JQuery</h2>
        

            <h4 class="demo"> List of Category</h4>

            <div class="row">
                <div class="col-md-12 dd" id="nestable-wrapper">
                	  <ol class="dd-list list-group">
                        @foreach($categories as $k => $category)
                            <li class="dd-item list-group-item" data-id="{{ $category['category_id'] }}" >
                                <div class="dd-handle" >{{ $category['name'] }}</div>
                                <div class="dd-option-handle">
                                    <a href="" class="btn btn-success btn-sm" >Edit</a> 
                                    <a href="" class="btn btn-danger btn-sm" >Delete</a> 
                                </div>

                                @if(!empty($category->categories))
                                    @include('livewire.child-category-view', [ 'category' => $category])
                                @endif
                            </li>
                        @endforeach
                    </ol>
                    
                </div>
            </div>

            <div class="row">
                <form action="" method="post">
                    @csrf
                    <textarea style="display: none;" name="nested_category_array" id="nestable-output"></textarea>
                    <button type="submit" class="btn btn-success" style="margin-top: 15px;" >Save category</button>
                </form>
            </div>
            
            
        </div>   
 @endsection       
@extends('layouts.app')
@section('content')

        <div class="container mx-auto">


        	<div class="bg-white p-4 shadow-md my-4">
            <div class="grid grid-cols-12 gap-4">
                <div class="col-span-12">
                    <h2 class="text-lg font-bold pb-4"> {{ (isset($category['category_id']))? "Edit" : "Create" }} Category Form</h2>
                </div>
            </div>

            <div class="">
            <form action="{{ route('store') }}" method="post">
                @csrf
                @if(isset($category['category_id']))
                    <input type="hidden" name="category_id" value="{{ $category['category_id'] }}" >
                @endif
                <div class="grid grid-cols-12 gap-4">
                    <div class="col-span-12">
                        <label for="" class="block mb-2">Name</label>
                        <input type="text" name="name" class="form-control px-2 border border-black" value="{{ (isset($category['name']))? $category['name'] : '' }}" >
                        @if($errors->first('name'))
                            <label for="" style="color:red;">{{ $errors->first('name') }}</label>
                        @endif
                    </div>
                    <div class="col-span-12">
                        <label for="" class="block mb-2">Parent Category ID</label>
                        <select name="parent_id" class="form-control border border-black">
                            <option value="">Choose One</option>
                            @foreach($categories as $k => $v)
                                <option value="{{ $v['category_id'] }}" {{ (isset($category['parent_id']) && $category['parent_id'] == $v['category_id'])? 'selected="selected"' : '' }} >{{ $v['name'] }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-span-12">
                    	<input type="submit" class="bg-black text-white rounded-full inline-block px-4 py-2 pointer cursor-pointer" value="Save">
                    </div>
                </div>

                
          

            </form>
        </div>
    </div>
        </div>
@endsection        


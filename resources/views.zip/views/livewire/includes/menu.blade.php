<!-- <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
    <a class="navbar-brand" href="">Category and SubCategory</a>

    <ul class="navbar-nav">
        <li class="nav-item">
        <a class="nav-link" href="#">List of Category</a>
        </li>
        <li class="nav-item">
        <a class="nav-link" href="{{ route('create') }}">Create Category</a>
        </li>
    </ul>
</nav> -->